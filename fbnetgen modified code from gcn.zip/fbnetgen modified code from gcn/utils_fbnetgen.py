import numpy as np
import torch
from torch.utils.data import TensorDataset
from sklearn.metrics import confusion_matrix, f1_score, roc_auc_score

def prepare_abide_time_series(X_loaded, Y_loaded):
    """
    Cleans raw ABIDE time-series data:
    1. Smartly detects which dimension is ROIs and which is Time.
    2. Ensures shape is [ROIs, TimePoints] for every subject.
    3. Crops all subjects to uniform dimensions to prevent inhomogeneous shape errors.
    """
    processed_X = []
    
    # 1. Figure out which axis is the ROI axis by finding the most common dimension size
    # In ABIDE, ROIs are usually fixed (e.g., 160), while timepoints vary wildly (115, 176, 296, etc.)
    shapes = [x.shape for x in X_loaded]
    dim0_uniques = len(set([s[0] for s in shapes]))
    dim1_uniques = len(set([s[1] for s in shapes]))
    
    # The dimension that varies the least across the 825 subjects is the ROI dimension
    roi_axis = 0 if dim0_uniques <= dim1_uniques else 1
    time_axis = 1 if roi_axis == 0 else 0
    
    # Find the absolute minimums across the dataset to crop uniformly
    min_rois = min([s[roi_axis] for s in shapes])
    min_time = min([s[time_axis] for s in shapes])
    
    for subj in X_loaded:
        # If ROIs were originally on the second axis, transpose so it becomes [ROIs, TimePoints]
        if roi_axis == 1:
            subj = subj.T
            
        # Crop to guarantee every single array is exactly (min_rois, min_time)
        subj = subj[:min_rois, :min_time]
        processed_X.append(subj)

    # Convert to 3D PyTorch Tensors: [Num_Subjects, Num_ROIs, TimePoints]
    X_tensor = torch.tensor(np.array(processed_X), dtype=torch.float32)
    Y_tensor = torch.tensor(Y_loaded, dtype=torch.long)

    return TensorDataset(X_tensor, Y_tensor), X_tensor, Y_tensor, min_time
def calculate_metrics(y_true, y_pred, y_scores):
    """
    Computes standard evaluation metrics.
    """
    # Ensure labels are explicitly 0 and 1
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    
    sen = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spe = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    acc = (tn + tp) / len(y_true)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    try:
        auc = roc_auc_score(y_true, y_scores)
    except ValueError:
        auc = 0.5  # Default to 0.5 if only one class is present in a batch

    return sen, spe, acc, f1, auc