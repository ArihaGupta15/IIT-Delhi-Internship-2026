import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
from sklearn.model_selection import StratifiedKFold, train_test_split
from colorama import Fore, Style

# Import from our new utility file
from utils_fbnetgen import prepare_abide_time_series, calculate_metrics

# ==========================================
# ENVIRONMENT & SEED SETUP
# ==========================================
seed = 89

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

os.environ['PYTHONHASHSEED'] = str(seed)
set_seed(seed)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

g = torch.Generator()
g.manual_seed(seed)

# ==========================================
# MODEL ARCHITECTURE
# ==========================================
class CustomDenseGCNConv(nn.Module):
    """
    A pure PyTorch implementation of Dense Graph Convolution.
    Bypasses the need for torch_geometric entirely to avoid DLL blocks.
    """
    def __init__(self, in_features, out_features):
        super(CustomDenseGCNConv, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(in_features, out_features))
        self.bias = nn.Parameter(torch.Tensor(out_features))
        nn.init.xavier_uniform_(self.weight)
        nn.init.zeros_(self.bias)

    def forward(self, x, adj):
        support = torch.bmm(adj, x)
        out = torch.matmul(support, self.weight)
        return out + self.bias


class TimeSeriesEncoder(nn.Module):
    def __init__(self, hidden_dim=64):
        super(TimeSeriesEncoder, self).__init__()
        self.conv1d = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=16, kernel_size=7, padding=3),
            nn.BatchNorm1d(16),
            nn.ReLU(),
            nn.MaxPool1d(2),
            nn.Conv1d(in_channels=16, out_channels=32, kernel_size=5, padding=2),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(16)
        )
        self.fc = nn.Linear(32 * 16, hidden_dim)

    def forward(self, x):
        B, N, T = x.shape
        x_reshaped = x.view(B * N, 1, T)
        feat = self.conv1d(x_reshaped) 
        feat = feat.view(B * N, -1)     
        feat = self.fc(feat)            
        return feat.view(B, N, -1)      


class GraphGenerator(nn.Module):
    def __init__(self, hidden_dim):
        super(GraphGenerator, self).__init__()
        self.temperature = nn.Parameter(torch.tensor(1.0))

    def forward(self, H):
        H_norm = F.normalize(H, p=2, dim=-1)
        adj = torch.bmm(H_norm, H_norm.transpose(1, 2))  
        adj = F.softmax(adj / self.temperature, dim=-1)
        return adj


class FBNetGen(nn.Module):
    def __init__(self, hidden_dim=64, num_classes=2, dropout=0.3):
        super(FBNetGen, self).__init__()
        self.p = dropout
        
        self.ts_encoder = TimeSeriesEncoder(hidden_dim=hidden_dim)
        self.graph_gen = GraphGenerator(hidden_dim=hidden_dim)
        
        # Using our custom pure PyTorch implementation
        self.conv1 = CustomDenseGCNConv(hidden_dim, 128)
        self.conv2 = CustomDenseGCNConv(128, 64)
        self.conv3 = CustomDenseGCNConv(64, 32)
        
        self.lin1 = nn.Linear(32, num_classes)

    def forward(self, x):
        node_feats = self.ts_encoder(x)
        adj = self.graph_gen(node_feats)
        
        h = F.relu(self.conv1(node_feats, adj))
        h = F.dropout(h, p=self.p, training=self.training)
        
        h = F.relu(self.conv2(h, adj))
        h = F.dropout(h, p=self.p, training=self.training)
        
        h = F.relu(self.conv3(h, adj))
        
        graph_emb = h.mean(dim=1)  # Global mean pooling
        out = self.lin1(graph_emb)
        return out, graph_emb

# ==========================================
# TRAINING & TESTING FUNCTIONS
# ==========================================
def GCN_train(model, optimizer, loader):
    model.train()
    loss_all = 0
    for x_batch, y_batch in loader:
        x_batch, y_batch = x_batch.to(device), y_batch.to(device)
        
        optimizer.zero_grad()
        output, _ = model(x_batch)
        loss = F.cross_entropy(output, y_batch)
        loss.backward()
        
        loss_all += loss.item() * x_batch.size(0)
        optimizer.step()
        
    return loss_all / len(loader.dataset)


def GCN_test(model, loader):
    model.eval()
    pred, scores, label = [], [], []
    loss_all = 0
    
    with torch.no_grad():
        for x_batch, y_batch in loader:
            x_batch, y_batch = x_batch.to(device), y_batch.to(device)
            output, _ = model(x_batch)
            loss = F.cross_entropy(output, y_batch)
            loss_all += loss.item() * x_batch.size(0)
            
            probs = F.softmax(output, dim=1)
            scores.append(probs[:, 1])
            pred.append(probs.max(dim=1)[1])
            label.append(y_batch)

    y_pred = torch.cat(pred).cpu().numpy()
    y_scores = torch.cat(scores).cpu().numpy()
    y_true = torch.cat(label).cpu().numpy()

    epoch_sen, epoch_spe, epoch_acc, epoch_f1, epoch_auc = calculate_metrics(y_true, y_pred, y_scores)
    
    return epoch_sen, epoch_spe, epoch_acc, epoch_f1, epoch_auc, loss_all / len(loader.dataset)

# ==========================================
# DATA LOADING & PREPARATION
# ==========================================
X_new = np.load(r'C:\Users\DELL\Downloads\ABIDE_data\ABIDE_data\Dosenbach\X.npz')
X_loaded = [X_new[key] for key in X_new.files]
Y_loaded = np.load(r'C:\Users\DELL\Downloads\ABIDE_data\ABIDE_data\Dosenbach\Y.npy')

print(f"Loaded {len(X_loaded)} subjects.")

dataset, X_tensor, Y_tensor, min_time = prepare_abide_time_series(X_loaded, Y_loaded)
labels = Y_tensor.numpy()

print(f"Data tensor shape: {X_tensor.shape}") 
print(f"Uniform Time Length applied: {min_time}\n")

# ==========================================
# 10-FOLD CROSS VALIDATION
# ==========================================
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
eval_metrics = np.zeros((skf.n_splits, 5))

for n_fold, (train_val_idx, test_idx) in enumerate(skf.split(X_tensor, labels)):
    print(f"\n--- Starting Fold {n_fold + 1} ---")
    
    train_val_labels = labels[train_val_idx]
    
    train_idx, val_idx = train_test_split(
        np.arange(len(train_val_idx)), 
        test_size=0.1, 
        shuffle=True, 
        stratify=train_val_labels, 
        random_state=seed
    )
    
    train_sub_idx = train_val_idx[train_idx]
    val_sub_idx = train_val_idx[val_idx]

    train_loader = DataLoader(Subset(dataset, train_sub_idx), batch_size=32, shuffle=True, num_workers=0, worker_init_fn=seed_worker, generator=g)
    val_loader = DataLoader(Subset(dataset, val_sub_idx), batch_size=32, shuffle=False, num_workers=0, worker_init_fn=seed_worker, generator=g)
    test_loader = DataLoader(Subset(dataset, test_idx), batch_size=32, shuffle=False, num_workers=0, worker_init_fn=seed_worker, generator=g)

    model = FBNetGen(hidden_dim=64, num_classes=2, dropout=0.3).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=5e-4)

    best_val_acc = 0
    best_test_metrics = [0, 0, 0, 0, 0] 

    for epoch in range(50):
        t_loss = GCN_train(model, optimizer, train_loader)
        val_sen, val_spe, val_acc, val_f1, val_auc, v_loss = GCN_test(model, val_loader)
        test_sen, test_spe, test_acc, test_f1, test_auc, _ = GCN_test(model, test_loader)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_test_metrics = [test_sen, test_spe, test_acc, test_f1, test_auc]
            
        print(
            f"CV: {n_fold + 1:03d}, "
            f"Epoch: {epoch + 1:03d}, "
            f"{Fore.RED}Train Loss: {t_loss:.5f}{Style.RESET_ALL}, "
            f"Val Loss: {v_loss:.5f}, "
            f"{Fore.GREEN}Val ACC: {val_acc:.5f}{Style.RESET_ALL}, "
            f"Val AUC: {val_auc:.5f}, "
            f"{Fore.BLUE}Test ACC: {test_acc:.5f}{Style.RESET_ALL}, "
            f"Test AUC: {test_auc:.5f}"
        )
            
    eval_metrics[n_fold] = best_test_metrics

# ==========================================
# FINAL RESULTS SUMMARY
# ==========================================
print("\n" + "="*50)
print("FINAL RESULTS (Selected by Max Validation Accuracy)")
print("="*50)

eval_df = pd.DataFrame(eval_metrics)
eval_df.columns = ['SEN', 'SPE', 'ACC', 'F1', 'AUC-ROC']
eval_df.index = [f'Fold_{i + 1:02d}' for i in range(skf.n_splits)]
print(eval_df)

print(f'\nAverage Sensitivity: {eval_metrics[:, 0].mean():.4f} ± {eval_metrics[:, 0].std():.4f}')
print(f'Average Specificity: {eval_metrics[:, 1].mean():.4f} ± {eval_metrics[:, 1].std():.4f}')
print(f'Average Accuracy:    {eval_metrics[:, 2].mean():.4f} ± {eval_metrics[:, 2].std():.4f}')
print(f'Average F1-Score:    {eval_metrics[:, 3].mean():.4f} ± {eval_metrics[:, 3].std():.4f}')
print(f'Average AUC-ROC:     {eval_metrics[:, 4].mean():.4f} ± {eval_metrics[:, 4].std():.4f}')